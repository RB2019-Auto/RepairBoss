import React from 'react';
import PropTypes from 'prop-types';
import style from './home.css';

const Test = ({ title }) => (
  <div className={style['hello-world']}>{title}</div>
);

Test.propTypes = {
  title: PropTypes.string,
};

export default Test;