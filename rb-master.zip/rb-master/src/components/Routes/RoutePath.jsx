export const RoutePath = {
  login: '/login',
  register:'/register',
  pricing:'/pricing',
  getEstimate:'/get-estimate',
  home:'/',
}