import React from 'react';
import {Images} from '../landing/Images'
class Footer extends React.Component{

  constructor (props){
    super(props);
  }


  render() {
    return(
      <React.Fragment>
        <footer className="footer">
          <div className="container">
            <div className="row">
              <div className="footer_block">
                <div className="col-md-1 footer_col">
                  <a className="footer-logo" href="/"><img src={Images.footer_logo} alt="Logo"/></a>
                </div>
                <div className="col-md-3 footer_col">
                  <h3>Repair Boss</h3>
                  <ul>
                    <li><a href="#">About Us</a></li>
                    <li><a href="#">Our Services</a></li>
                    <li><a href="#">Get Estimate</a></li>
                    <li><a href="#">Find a Garage</a></li>
                  </ul>
                </div>
                <div className="col-md-4 footer_col">
                  <h3>Address</h3>
                  <address>
                    <p>1140 Sheppard Avenue West<br />
                      North York<br />Ontario. M3K2A2
                    </p>
                  </address>
                </div>
                <div className="col-md-4 footer_col">
                  <h3>Social Media</h3>
                  <ul className="social-icons">
                    <li><a className="facebook" href="#"><i className="fa fa-facebook-f"></i></a></li>
                    <li><a className="twitter" href="#"><i className="fa fa-twitter"></i></a></li>
                    <li><a className="instagram" href="#"><i className="fa fa-instagram"></i></a></li>
                  </ul>
                  <div className="copyright">
                    <p><i className="copyright">C</i> 2019 RepairBoss, All Rights Reserved</p>
                    <p>
                      <a href="#">Term of use</a><span>|</span>
                      <a href="#">Privacy Policy</a>
                    </p>
                  </div>
                </div>
              </div>

            </div>
          </div>
        </footer>
      </React.Fragment>
    );
  };

}
export default Footer;