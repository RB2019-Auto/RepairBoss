import React from "react";
import validator from 'validator';
import  {checkUniqueEmail} from '../../services/validations.service';
import {toast} from "react-toastify";

export const required = (value) => {

  if (!value.toString().trim().length) {

    // We can return string or jsx as the 'error' prop for the validated Component
    return <span className="error"> This field is required</span>
  }
};

const isUnique = async (payloads) => {
  return  checkUniqueEmail(payloads).then((res) => {
    return true;
  }).catch((error)=>{
    return  false
  });
}

export const unique =  async (value) => {

  var payloads = {email:value};
  let isvalid = await isUnique(payloads);
  return isvalid;

};
export const alphabet =  async (value) => {
  var regExp = /[a-z]/i;
  if (regExp.test(value)) {
    return false;
  } else{ return true }

};

export const required_validate = (value) => {

  if (!value.toString().trim().length) {

    // We can return string or jsx as the 'error' prop for the validated Component
    return <span className="error"> This field is required</span>
  }
};

export const required_checkbox = (value,props) => {

  if (!value || (props.isCheckable && !props.checked)) {
    return <span className="form-error is-visible">Required</span>;
  }
};

export const email = (value) => {

  if (validator.isEmail(value)) {
    return true;
  } return false
};

export  const lt = (value, props) => {
  // get the maxLength from component's props
  if (!value.toString().trim().length > props.maxLength) {
    // Return jsx
    return <span className="error">The value exceeded {props.maxLength} symbols.</span>
  }
};

export  const password = (value, props, components) => {
  // NOTE: Tricky place. The 'value' argument is always current component's value.
  // So in case we're 'changing' let's say 'password' component - we'll compare it's value with 'confirm' value.
  // But if we're changing 'confirm' component - the condition will always be true
  // If we need to always compare own values - replace 'value' with components.password[0].value and make some magic with error rendering.
  if (value !== components['confirm'][0].value) { // components['password'][0].value !== components['confirm'][0].value
    // 'confirm' - name of input
    // components['confirm'] - array of same-name components because of checkboxes and radios
    return <span className="error">Passwords are not equal.</span>
  }
};