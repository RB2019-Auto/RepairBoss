import React from 'react';
import {Images} from '../landing/Images'
import {NavLink,Link,withRouter} from 'react-router-dom';
import {connect} from "react-redux";
import * as auth from "../../store/actions/auth";
import { bindActionCreators } from 'redux';
import storage from "../../utils/storage";
import {RoutePath} from '../../components/Routes/RoutePath';


class Header extends React.Component{

  constructor (props){
    super(props);
    this.state = {

    }
  }

  myFunction = () => {

    if (document.body.scrollTop > 60 || document.documentElement.scrollTop > 60) {
      document.getElementById("header").className = "header sticky";
    } else {
      document.getElementById("header").className = "header";
    }

  }

  componentDidMount(){

    document.addEventListener('scroll', this.myFunction, false);

    const token = storage.get('token');

    if (token) {
     this.props.token_user();
    }

  }

  componentWillUnmount() {

    document.removeEventListener('scroll', this.myFunction, false);

  }


  focusOnArea = (section) => {

    this.props.history.push(RoutePath.home);

    setTimeout(function () {
      let aboutSection =  document.getElementById(section).scrollIntoView({
        behavior: 'smooth'
      });
    }, 0)

  }

  logOut = () => {

    this.props.log_out();
    this.props.history.push(RoutePath.login);

  }


  render() {

    const { current_user } = this.props;
console.log('header',current_user);
    return(

      <React.Fragment>

            <header className="header " id="header">
                <div className="container">
                  <div className="row">
                    <nav className="navbar navbar-expand-lg navbar-light">
                      <a className="logo" href="#"><img src={Images.logo} alt="Logo"/></a>
                      <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <span className="navbar-toggler-icon"></span>
                      </button>
                      <div className="collapse navbar-collapse" id="navbarSupportedContent">

                        <ul className="navbar-nav mr-auto">

                          <li className="nav-item">
                            <NavLink exact className="nav-link" activeClassName="active" to="/">Home</NavLink>
                          </li>
                          <li className="nav-item">
                            <a className="nav-link" onClick={() => this.focusOnArea('about')} href="javascript:void(0);">About</a>
                          </li>
                          <li className="nav-item">
                            <a className="nav-link" onClick={() => this.focusOnArea('services')} href="javascript:void(0);">Services</a>
                          </li>
                          <li className="nav-item">
                            <NavLink className="nav-link" activeClassName="active" to="/find-garage">Find a Garage</NavLink>
                          </li>
                          <li className="nav-item">
                            <NavLink className="nav-link" activeClassName="active" to="/pricing">Pricing</NavLink>
                          </li>
                          <li className="nav-item">
                            <NavLink className="nav-link" activeClassName="active" to="/get-estimate">Get Estimate</NavLink>
                          </li>

                          {(
                              typeof current_user == "undefined" ||
                              !current_user.hasOwnProperty('name')
                          )  &&
                          <li className="nav-item">
                            <NavLink className="nav-link" activeClassName="active" to="/login">Sign In</NavLink>
                          </li>
                          }

                          {(
                              typeof current_user == "undefined" ||
                              !current_user.hasOwnProperty('name')
                          )  &&

                          <li className="nav-item">
                            <NavLink className="nav-link signup-link" activeClassName="active" to="/register">Register</NavLink>
                          </li>
                          }

                          { (
                              typeof current_user != "undefined" &&
                               current_user.hasOwnProperty('name')
                            ) &&
                            <li className="nav-item">
                              <a className="nav-link" href="javascript:void(0);">{current_user.name}</a>
                            </li>
                          }

                          {(
                              typeof current_user != "undefined" &&
                              current_user.hasOwnProperty('name')
                          )  &&
                          <li className="nav-item">
                            <a className="nav-link signup-link" onClick={this.logOut} href="javascript:void(0);">Logout</a>
                          </li>
                          }

                        </ul>
                      </div>
                    </nav>
                  </div>
                </div>
              </header>


      </React.Fragment>
    );
  };

}

export default withRouter(connect(
    ({auth}) => ({
      current_user: auth.info
    }),
    dispatch => bindActionCreators({...auth }, dispatch)
) (Header));
