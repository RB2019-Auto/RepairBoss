export const Images =  {
  management_thumb: require("../../assets/images/management-thumb.jpg"),
  auto_referral: require("../../assets/images/auto-referral.jpg"),
  left_arrow: require("../../assets/images/left-arrow.png"),
  lock: require("../../assets/images/lock.png"),
  Union: require("../../assets/images/Union.png"),
  btm: require("../../assets/images/btm.png"),
  pay1: require("../../assets/images/pay1.png"),
  pay2: require("../../assets/images/pay2.png"),
  pay3: require("../../assets/images/pay3.png"),
  pay4: require("../../assets/images/pay4.png"),
}