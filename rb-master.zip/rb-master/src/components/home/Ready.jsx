import React, { useState,useEffect } from 'react';

function Ready(props) {

    return (
        <form className="get_form">
            <div className="form-group col-md-3 col-sm-6">
                <label>Vehicle</label>
                <select className="form-control select_field">
                    <option value="">Choose Your Vechile</option>
                    <option value="Audi">Audi</option>
                    <option value="BMW">BMW</option>
                    <option value="Range Rover">Range Rover</option>
                    <option value="Porsche">Porsche</option>
                </select>
            </div>
            <div className="form-group col-md-3 col-sm-6">
                <label>Make</label>
                <select className="form-control select_field">
                    <option value="">Search Make</option>
                    <option value="2018">2018</option>
                    <option value="2017">2017</option>
                    <option value="2016r">2016</option>
                    <option value="2015">2015</option>
                </select>
            </div>
            <div className="form-group col-md-3 col-sm-6">
                <label>Model</label>
                <select className="form-control select_field">
                    <option value="">Search Model</option>
                    <option value="Audi">Audi A</option>
                    <option value="BMW">BMW B</option>
                    <option value="Range Rover">Range Rover S</option>
                    <option value="Porsche">Porsche D</option>
                </select>
            </div>
            <div className="form-group col-md-3 col-sm-6">
                <label>Edition</label>
                <select className="form-control select_field">
                    <option value="">Find Edition</option>
                    <option value="V6">V6 5-Speed Automatic</option>
                    <option value="V6">V6 5-Speed Automatic</option>
                    <option value="V6">V6 5-Speed Automatic</option>
                    <option value="V6">V6 5-Speed Automatic</option>
                </select>
            </div>
        </form>
    );
}

export default Ready;