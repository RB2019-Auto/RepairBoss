import * as io from 'socket.io-client';
import url from '../config/api'

var UniversalSocket = {
};
const init = {
        io : () => io.connect(url.apiBaseUrl ,{secure:true}),
        disconnect : ()=> io.disconnect()
};

UniversalSocket.io = init.io();
  
export default {UniversalSocket};



