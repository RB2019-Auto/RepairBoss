const getFromstorage = (key) => {
	return localStorage.getItem(key);
};

const removeFromStorage = (key) => {
	return localStorage.removeItem(key);
};

const saveToStorage = (key, value) => {
  		try {
		    return localStorage.setItem(key, value);
		} catch (error) {
		    console.log(`
		        Error in saving ${key } token
		    `)
		}
	return null;
};

const clearStorage = () => {

	return localStorage.clear();

};

const storage = {
	get: (key) => getFromstorage(key),
	set: (key, value) => saveToStorage(key, value),
	clear:() =>clearStorage(),
	remove : (key) => removeFromStorage(key)
};

export default storage;