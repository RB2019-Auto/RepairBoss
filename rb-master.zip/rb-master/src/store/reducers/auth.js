import {
    LOGIN_TYPE,
    AUTHENTICATE_THE_USER
   } from '../actions/action-types';
import { initialState } from './initial';

export default (state = initialState.auth, action) => {
    switch (action.type) {
        case LOGIN_TYPE:
            return {
                    ...state,
                    info:action.payload
            }
            case AUTHENTICATE_THE_USER:
            return {
                    ...state,
                    info:action.payload
            }
        default:
          return state
    }
}