import { combineReducers } from 'redux';
import auth from "./auth";
import register from "./register";

export default function getRootReducer() {
  return combineReducers({
    auth,register
  });
}
