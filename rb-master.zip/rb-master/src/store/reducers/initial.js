const initialState = {
  auth: {
    updated_at: null,
  },
  register : {
    type:null,
    basic_detail:{},
    experties:{},
    selected_plan:{},
    stripe_token:'',
    forms:[],
    otherdetails:{}

  },
  error: null,
};

export {
  initialState,
};
