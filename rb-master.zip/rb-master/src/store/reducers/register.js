import {
    REGISTER_STACK,
} from '../actions/action-types';
import { initialState } from './initial';

export default (state = initialState.register, action) => {
    switch (action.type) {
        case REGISTER_STACK:
            return {
                    ...state,
                    info:action.payload
            }

        default:
          return state
    }
}