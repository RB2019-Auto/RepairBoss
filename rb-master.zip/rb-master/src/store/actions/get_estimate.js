import {
    LOGIN_TYPE,
    REGISTER_STACK
} from './action-types';
import axios from "../../utils/api";


import {saveToStorage} from "./auth"

export  const registerStack = payloads => dispatch => {
    dispatch({ type: REGISTER_STACK,  payload:{} });
}

export const signUp = payloads => dispatch => axios.post('/signup',
    { payloads }).then((res) => {

    if (res.data.success) {
        saveToStorage(res);
        dispatch({ type: LOGIN_TYPE,  payload:res.data.data });
    }

    console.log(res,'in action');

    return res.data;


}).catch((error) => {

    throw error.response.data;

});






