import {
   LOGIN_TYPE
  } from './action-types';

import axios from '../../utils/api';
import storage from '../../utils/storage';
import {RoutePath} from "../../components/Routes/RoutePath";

const saveToken = token => storage.set('token', token);
const saveUserType = type => storage.set('userType', type);
const savecurrentUserType = user =>  storage.set('user', user);
const saveUserId = id =>  storage.set('userId', id);


export const loginUser = payloads => dispatch => axios.post('/login',
  { payloads }).then((res) => {

    if (res.data.success) {
        saveToStorage(res);
        dispatch({ type: LOGIN_TYPE,  payload:res.data.data });
    }

    return res.data;


  }).catch((error) => {

      throw error.response.data;

});

export const saveToStorage = (res) => {
    if (res.data.success) {
        saveToken(res.data.data.access_token);
        saveUserType(res.data.data.role);
        saveUserId(res.data.data._id);
        savecurrentUserType(JSON.stringify(res.data.data));
    }
}





/*export const register = payloads => dispatch => axios.post('/signup',
  { payloads }).then((res) => {
    if (res.data['success']) {
      saveToken(res.data.token);
      saveUserType(res.data.user.userType);
      dispatch({type: REGISTER_TYPE, payload:res.data });
    }
    return res.data;
  }).catch((error) => {
    console.log('catch login err',error)
    const res = {  message: 'Something went wrong,please try again' };
    return res;
});
*/


/*export const forgot_password = payloads => dispatch => axios.post('/forgotpassword',
  { payloads }).then((res) => {
    console.log('forgot password re',res.data)
    return res.data;

  }).catch((error) => {
    const res = {  message: 'Something went wrong,please try again' };
    return res;
});*/

export const token_user = payloads => dispatch => axios.get('/auth/userprofile',
    { payloads }).then((res) => {
    dispatch({ type: LOGIN_TYPE,  payload:res.data.data });

}).catch((error) => {
    const res = {  message: 'Something went wrong,please try again' };
    console.log(error.response);
});


export const log_out = payload => dispatch => {
    storage.clear();
    dispatch({ type: LOGIN_TYPE,  payload:{} });
}






