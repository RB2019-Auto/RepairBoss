export default {
  TWITTER_COMSUMER_KEY: "JzVi3D7s1BSDpNSMrlTSnjlri",
  TWITTER_CONSUMER_SECRET: "B5qLIpDNotDsW1Q849NwMVq23ezIHcDHZIwqMm7OSG85ZIP5QH",
  INSTAGRAM_CLIENT_ID: "ebec59a3397d467cab59182b49279c6b",
  INSTAGRAM_REDIRECT_URL: "https://repairboss.com/login",
  GOOGLE_CLIENT_ID: '815598008016-dlgof92v965s9fiv9b5594eeutaopo0v.apps.googleusercontent.com',
  // YOUTUBE_CLIENT_ID:'374656106782-ckv8vks3c3keup8ln2aov0jpgtc70lmm.apps.googleusercontent.com',
  YOUTUBE_API_KEY:"AIzaSyDPgExf-TTpZ3-CvRRAo_BItXl_iKCIl4c"  //"AIzaSyDIsVLY64cOafvrjXp6oMzzEO65XENR"
}