import React from 'react';
import Header from '../../components/common/Header';
import Footer from '../../components/common/Footer';

class Layout extends React.Component {
  constructor(props) {
    super(props);
  }

  render() {
    return (
        <React.Fragment>
          <Header />
          {this.props.children}
          <Footer />
        </React.Fragment>

    )
  }
}



export default Layout;
