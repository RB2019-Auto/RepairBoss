import React from 'react';


class NotFound extends React.Component {
  constructor(props) {
    super(props);
  }

  render() {
    return (
      <React.Fragment>
        <div>No Route Matched</div>
      </React.Fragment>
    )
  }
}



export default NotFound;
